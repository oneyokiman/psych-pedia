# Git 命令快速指南 - Psych-Pedia

## 🚀 初次设置（仅需一次）

### 1. 配置 Git 用户信息
```powershell
git config --global user.email "你的GitHub邮箱"
git config --global user.name "你的GitHub用户名"
```

### 2. 初始化本地仓库
```powershell
cd d:\02_Wrok_file\project\psych-pedia
git init
git add .
git commit -m "Initial commit: Psych-Pedia 精神药理百科"
```

### 3. 连接到 GitHub 远程仓库
```powershell
# 替换 YOUR_USERNAME 为你的 GitHub 用户名
git remote add origin https://github.com/YOUR_USERNAME/psych-pedia.git

# 验证连接（输出应该显示 origin）
git remote -v
```

### 4. 推送到 GitHub
```powershell
git branch -M main
git push -u origin main
```

---

## 📝 日常工作流程

### **当你修改了文件后**

#### 步骤 1：查看修改状态
```powershell
git status
```
输出示例：
```
On branch main
Changes not staged for commit:
  modified:   public/drugs.json
  modified:   App.tsx
```

#### 步骤 2：添加你修改的文件
```powershell
# 添加特定文件
git add public/drugs.json

# 或添加所有修改
git add .
```

#### 步骤 3：提交更改（带说明信息）
```powershell
git commit -m "添加新药物：利培酮 (Risperidone)"
```

#### 步骤 4：推送到 GitHub
```powershell
git push origin main
```

---

## 📚 常用命令详解

| 命令 | 说明 | 示例 |
|------|------|------|
| `git status` | 查看当前工作状态 | `git status` |
| `git add .` | 添加所有修改文件 | `git add .` |
| `git add <文件>` | 添加特定文件 | `git add public/drugs.json` |
| `git commit -m "信息"` | 提交更改 | `git commit -m "修复 D2 受体描述"` |
| `git push origin main` | 推送到 GitHub | `git push origin main` |
| `git pull origin main` | 从 GitHub 拉取最新代码 | `git pull origin main` |
| `git log` | 查看提交历史 | `git log` |
| `git diff` | 查看具体修改 | `git diff public/drugs.json` |

---

## 🔄 最简单的日常流程（3 步）

**只需记住这 3 条命令：**

```powershell
# 1. 查看修改了什么
git status

# 2. 提交更改（添加所有文件 + 提交 + 推送）
git add .
git commit -m "你的更改说明"
git push origin main

# 完成！GitHub 和 Vercel 自动更新网站
```

---

## 💡 实际操作示例

### 场景：添加新的药物数据

```powershell
# 1. 修改 public/drugs.json（用编辑器打开，加入新药物）

# 2. 检查修改
git status
# 输出：modified: public/drugs.json

# 3. 提交并推送
git add public/drugs.json
git commit -m "添加新药物：帕利哌酮 (Paliperidone)"
git push origin main

# ✅ 完成！Vercel 自动部署，1-2 分钟后网站更新
```

---

## 🆘 常见问题

### 问：如何撤销最后一次提交？
```powershell
git reset HEAD~1
```

### 问：如何查看哪些文件被修改了？
```powershell
git diff --name-only
```

### 问：如何查看某个文件的修改历史？
```powershell
git log -- public/drugs.json
```

### 问：推送时报错 "rejected"？
```powershell
# 先拉取最新代码
git pull origin main

# 然后再推送
git push origin main
```

---

## 🎯 GitHub 仓库设置

1. 在 GitHub 创建新仓库 `psych-pedia`（保持为公开 Public）
2. 不要初始化任何文件（README, .gitignore 等）
3. 点击 **Create repository**
4. 然后按照上面的"初次设置"第 3、4 步操作

---

## 📱 Vercel 自动部署设置

### 第一次连接 GitHub 到 Vercel：

1. 访问 [vercel.com](https://vercel.com)
2. 用 GitHub 账号登录（如果没有，先创建 Vercel 账号）
3. 点击 **Add New** → **Project**
4. 选择 `psych-pedia` 仓库
5. **Framework**: 选择 **Vite**
6. **Build Command**: `npm run build`
7. **Output Directory**: `dist`
8. 点击 **Deploy**

### 之后的工作流程：
```
修改本地文件 → git commit & push → GitHub 更新 → Vercel 自动部署 → 网站更新
```

完全自动化，无需手动操作！

---

## ✨ 工作流总结

```
┌─────────────────────────────────────────────────────────────┐
│ 1. 编辑 drugs.json / principles.json / 其他文件             │
│    (用任何编辑器，本地修改)                                   │
├─────────────────────────────────────────────────────────────┤
│ 2. git add . && git commit -m "你的说明" && git push         │
│    (上传到 GitHub)                                           │
├─────────────────────────────────────────────────────────────┤
│ 3. Vercel 自动检测到 GitHub 的更新                           │
│    自动触发 `npm run build` 和部署                           │
├─────────────────────────────────────────────────────────────┤
│ 4. 1-2 分钟后，你的网站自动更新                              │
│    无需任何手动操作                                           │
└─────────────────────────────────────────────────────────────┘
```

---

## 🔗 快速链接

- GitHub: https://github.com/你的用户名/psych-pedia
- Vercel: https://psych-pedia.vercel.app
- Git 官网: https://git-scm.com
